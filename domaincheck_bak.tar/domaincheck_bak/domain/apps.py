from django.apps import AppConfig


class DomainConfig(AppConfig):
    name = 'domain'
