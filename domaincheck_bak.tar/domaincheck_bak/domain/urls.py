from django.urls import path
from .views import *


urlpatterns = [
    path('', domain_check, name='domcheck' ),
    #path('<str:domain>/', forcecheck),
    path('<int:domain_ID>/', forcecheck),
    ]
