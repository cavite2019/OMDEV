from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Domain_c
from .dom_mod.domain2 import *



# Create your views here.
def output(jinja_out):
    domain_list = Domain_c().querydomain()
    domainline = []
    for i4 in domain_list:
        combined = Domain_c().queryrow(i4)
        domainline.append(combined)
    jinja_list = {
        "domainline": domainline,
    }
    if jinja_out == "all":
        return jinja_list
    return jinja_list[jinja_out]



def domain_check(request):
    template = loader.get_template('domain_temp/index.html')
    return HttpResponse(template.render(output("all"), request))



def forcecheck(request, domain_ID):
    domain_forcecheckID(domain_ID)
    template = loader.get_template('domain_temp/index.html')
    return HttpResponse(template.render(output("all"), request))


