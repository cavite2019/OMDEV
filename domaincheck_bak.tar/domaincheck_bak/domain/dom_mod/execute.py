from .domain2 import *
import datetime, time,sqlite3

if __name__ == "__main__":
    domain_store()


