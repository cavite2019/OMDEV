#!/usr/bin/python3
#created by: Yroll Jay-R Macalino
from py_config import colordesign
class Collect():
    def __init__(self):
        self.answer = colordesign("cgreen") + "In process yet..." + colordesign("cnormal")
    def centos7(self):
        print(self.answer)
