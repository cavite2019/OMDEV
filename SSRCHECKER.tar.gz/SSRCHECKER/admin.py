from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(SSRinitModel)
admin.site.register(SSRIDCModel)
admin.site.register(SSRinitdataModel)