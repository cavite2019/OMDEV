from django.apps import AppConfig


class SsrcheckerConfig(AppConfig):
    name = 'SSRCHECKER'
